var PLAY=1;
var END=0;
var gameState=PLAY;
var trex,score=0;
var sun ,grass;
var obstacle
var cloud
var ground
var invisibleGround
function preload(){
  sunImg=loadImage("sun image.png")
  cloudImg=loadImage("PngItem_5336200.png")
  trexImg=loadImage("trx red 2.png");
  obstacle1=loadImage("obstacle lu.gif")
  obstacle2=loadImage("obstacle.png")
  grassImg=loadImage("unnamed.png")
}

function setup(){
createCanvas(windowWidth,windowHeight);
  
  grass=createSprite(width/2,height-10,width,125)
  grass.addImage("grass",grassImg)
  grass.scale=2
  
  trex=createSprite(60,height-20,width,145);
  trex.addAnimation("trex",trexImg)
  trex.setCollider('circle',0,0,50);
  trex.debug=true
  
sun=createSprite(width-50,100,10,10);  
sun.addAnimation("sun",sunImg)
  sun.scale=0.2 
  
invisibleGround=createSprite(width/2,height-10,width,125);
invisibleGround.visible=false;  
 invisibleGround.velocityX = -(6 + 3*score/100);
  
  score=0,
}

function draw(){
  background ("white")
  text("score:",500,30)
  score = score + Math.round(getFrameRate()/60);
    ground.velocityX = -(6 + 3*score/100);
  
//jump when the space key is pressed
    if(keyDown("space")&& trex.y >= 100) {
        trex.velocityY = -12;
    }
    
    //add gravity
    trex.velocityY = trex.velocityY + 0.8
   trex.collide(invisibleGround);
  spawnObstacles(); 
  spawnClouds();
  
  
  
   drawSprites();
}
function spawnClouds(){
if(frameCount%60===0){
   var cloud = createSprite(600,120,40,10);
    cloud.y = Math.round(random(80,120));
    cloud.velocityX = -3;
    cloud.addImage("cloud",cloudImg);
    cloud.scale=0.2
     //assign lifetime to the variable
    cloud.lifetime = 200;
   
    cloud.depth = sun.depth;
    sun.depth = sun.depth + 0;
   }   
}

function spawnObstacles(){
if(frameCount%80===0){
   var obstacle = createSprite(600,320,40,10);
    obstacle.y = Math.round(random(300,420));
    obstacle.velocityX = -9;
  obstacle.scale = 0.5
    obstacle.lifetime = 200;
   
    var rand = Math.round(random(1,2));
    switch(rand) {
      case 1: obstacle.addImage(obstacle1);
              break;
      case 2: obstacle.addImage(obstacle2);
              break;
      default: break;}
           
    
    trex.depth = obstacle.depth;
  
   }}   
  
  